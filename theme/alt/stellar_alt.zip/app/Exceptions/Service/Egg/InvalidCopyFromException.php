<?php

namespace Pterodactyl\Exceptions\Service\Egg;

use Pterodactyl\Exceptions\DisplayException;

class InvalidCopyFromException extends DisplayException
{
}
