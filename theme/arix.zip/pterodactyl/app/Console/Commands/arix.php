<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;

class Arix extends Command
{
  protected $signature = 'arix {action?}';
  protected $description = 'Semua perintah untuk Tema Arix di Pterodactyl.';

  public function handle()
  {
    $action = $this->argument('action');

    $title = new OutputFormatterStyle('#fff', null, ['bold']);
    $this->output->getFormatter()->setStyle('title', $title);

    $b = new OutputFormatterStyle(null, null, ['bold']);
    $this->output->getFormatter()->setStyle('b', $b);

    if ($action === null) {
      $this->line("
      <title>
      ░█████╗░██████╗░██╗██╗░░██╗
      ██╔══██╗██╔══██╗██║╚██╗██╔╝
      ███████║██████╔╝██║░╚███╔╝░
      ██╔══██║██╔══██╗██║░██╔██╗░
      ██║░░██║██║░░██║██║██╔╝╚██╗
      ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░╚═╝

      Terima kasih telah membeli tema Arix</title>

      > php artisan arix (untuk melihat menu ini)
      > php artisan arix install
      > php artisan arix update
      > php artisan arix uninstall
      ");
    } elseif ($action === 'install') {
      $this->install();
    } elseif ($action === 'update') {
      $this->update();
    } elseif ($action === 'uninstall') {
      $this->uninstall();
    } else {
      $this->error("Aksi tidak valid. Aksi yang didukung: install, update, uninstall");
    }
  }

  public function installOrUpdate($isUpdate = false)
  {
    if ($isUpdate) {
      $this->info("
        Perintah ini tidak direkomendasikan untuk digunakan secara manual.
        Perintah ini melewati beberapa file yang biasa digunakan untuk mencegah
        kehilangan data kustomisasi Anda. Jika terjadi error setelah update,
        silakan hubungi kami.
      ");
    }

#    if (config('app.version') !== '1.11.7') {
#      return $this->error("Tidak dapat melanjutkan instalasi. Versi terbaru Pterodactyl diperlukan. Versi Anda saat ini: " . config('app.version'));
#    }

    $confirmation = $this->confirm('Apakah semua dependensi yang diperlukan telah diinstal dari file readme?', 'yes');
    if (!$confirmation) return;

    $seed = 'AR174af947a65bce1e43851a660b95aadc';
    $endpoint = 'https://api.arix.gg/resource/arix-pterodactyl/verify';
    $response = Http::asForm()->post($endpoint, ['license' => $seed]);
    $responseData = $response->json();

#    if (!$responseData['success']) {
#      return $this->error('Gagal: Metode verifikasi tidak ditemukan. Periksa koneksi atau file yang rusak.');
#    }

    $versions = File::directories('./arix');
    if (empty($versions)) {
      $this->info('Tidak ada versi ditemukan di direktori /arix.');
      return;
    }

    $version = basename($this->choice('Pilih versi tema:', $versions));
    $this->info("Menginstal Tema Arix versi $version...");

    $excludeOption = $isUpdate
      ? "--exclude='routes.ts' --exclude='getServer.ts' --exclude='admin.blade.php' --exclude='admin.php' --exclude='ServerTransformer.php'"
      : '';

    exec("rsync -a $excludeOption arix/{$version}/ ./");

    $directoryPath = app_path('Http/Controllers/Admin/Arix');
    File::makeDirectory($directoryPath, 0755, true, true);

    $controllers1 = [
      'ArixController',
      'ArixAdvancedController',
      'ArixAnnouncementController',
      'ArixColorsController',
    ];

    $this->info('Memproses file instalasi awal...');
    $controllers2 = [
      'ArixComponentsController',
      'ArixLayoutController',
      'ArixMailController',
      'ArixMetaController',
      'ArixStylingController',
    ];

    $this->info('Menjalankan migrasi database...');
    $this->command('php artisan migrate --force');

    $this->info('Menginstal paket-paket yang diperlukan...');
    $this->info('Proses ini mungkin memakan waktu beberapa menit...');
    $this->command('yarn add @types/md5 md5 react-icons @types/bbcode-to-react bbcode-to-react i18next-browser-languagedetector@7.2.1');

    foreach ($controllers1 as $file) {
      $this->downloadArixFile($file, $version, $seed, $directoryPath);
      sleep(1);
    }

    foreach ($controllers2 as $file) {
      $this->downloadArixFile($file, $version, $seed, $directoryPath);
      sleep(1);
    }

    $this->info('Membangun ulang aset panel...');
    $this->command('yarn build:production');

    $this->info('Mengatur ulang izin file...');
    $this->command('chown -R www-data:www-data ' . base_path() . '/*');
    $this->command('chown -R nginx:nginx ' . base_path() . '/*');
    $this->command('chown -R apache:apache ' . base_path() . '/*');

    $this->info('Mengoptimalkan aplikasi...');
    $this->command('php artisan optimize:clear');
    $this->command('php artisan optimize');

    $pesan = $isUpdate
      ? "✅ Tema berhasil diperbarui!"
      : "✅ Tema berhasil diinstal!";

    $this->line("
      ╭───────────────────────────────╮
      │                               │
      │  $pesan
      │    ╰─╴   sukses!   ╶─╯         │
      │                               │
      ╰───────────────────────────────╯
    ");
  }

  private function downloadArixFile($filename, $version, $seed, $directoryPath)
  {
    $url = "https://downloads.arix.gg/{$version}/{$filename}.php?seed={$seed}";
    $response = Http::get($url);

    if ($response->successful()) {
      $filePath = $directoryPath . '/' . $filename . '.php';
      File::put($filePath, $response->body());
    } else {
      $this->error('Gagal mengunduh file ' . $filename . '.php. Silakan hubungi pengembang.');
    }
  }

  public function install()
  {
    $this->installOrUpdate();
  }

  public function update()
  {
    $this->installOrUpdate(true);
  }

  private function uninstall()
  {
    $this->line("Menghapus instalasi tema...");
    $this->command('php artisan down');
    $this->command('curl -L https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz | tar -xzv');
    $this->command('chmod -R 755 storage/* bootstrap/cache');
    $this->command('composer install --no-dev --optimize-autoloader');
    $this->command('php artisan view:clear');
    $this->command('php artisan config:clear');
    $this->command('php artisan migrate --seed --force');
    $this->command('chown -R www-data:www-data ' . base_path() . '/*');
    $this->command('chown -R nginx:nginx ' . base_path() . '/*');
    $this->command('chown -R apache:apache ' . base_path() . '/*');
    $this->command('php artisan queue:restart');
    $this->command('php artisan up');
  }

  private function command($cmd)
  {
    return exec($cmd);
  }
}