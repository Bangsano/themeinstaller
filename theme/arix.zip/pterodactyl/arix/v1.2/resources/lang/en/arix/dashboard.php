<?php

return [
    'join-our-discord' => 'Join our Discord',
    'members-online' => 'Members Online',
    'billing-area' => 'Billing area',
    'manage-your-services' => 'Manage your services',
    'supportcenter' => 'Support center',
    'get-support' => 'Get support',
    'server-status' => 'Server status',
    'check-server-status' => 'Check server status',
    'welcome-back' => 'Welcome back',
    'all-servers-you-have-access-to' => 'Here you can see all the servers you have access to.',
    'your-servers' => 'Showing your servers',
    'others-servers' => 'Showing others\' servers',
    'there-are-no-servers' => 'There are no other servers to display.',
    'there-are-no-servers-associated' => 'There are no servers associated with your account.',
    'manage-server' => 'Manage server',
];