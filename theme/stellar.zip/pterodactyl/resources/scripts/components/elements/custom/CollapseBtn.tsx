import * as React from 'react';
import * as Icon from 'react-feather';
import styled from 'styled-components/macro';

const HideShowIcon = styled.div`
    & > *{
        transition:transform .3s;
    }
    .stellar-collapsed & > * {
        transform:rotate(180deg);
    }
`

export default () => {
    const collapseClass = 'stellar-collapsed'; 

    if (localStorage.getItem('collapse') == 'true'){
        document.body.classList.add(collapseClass);
    } else {
        document.body.classList.remove(collapseClass);
    }

    const collapseBtn = () => {
        if (localStorage.getItem('collapse') == 'true'){
            localStorage.setItem('collapse', 'null');
            document.body.classList.remove(collapseClass);
        } else {
            localStorage.setItem('collapse', 'true');
            document.body.classList.add(collapseClass);
        }
    }

    return (
        <button onClick={collapseBtn}>
            <div className='icon'>
                <HideShowIcon>
                    <Icon.ArrowUp size={20}/> 
                </HideShowIcon>
            </div>
        </button>
    );
};
